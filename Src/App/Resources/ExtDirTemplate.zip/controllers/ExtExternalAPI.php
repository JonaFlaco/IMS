<?php 

namespace Ext\Controllers;

use App\Core\Controller;
use App\Exceptions\NotFoundException;

class Extexternalapi extends Controller{

    public function __construct(){
        parent::__construct();

    }

    public function index($id, $params){
        throw new NotFoundException();
    }


}

