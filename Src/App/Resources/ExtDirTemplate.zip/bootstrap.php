<?php

    require_once 'config/config.php';
    require_once 'helpers/misc_helper.php';
