<?php 

// namespace Ext\Triggers\ctype_name;

// use App\Core\BaseTrigger;

// class BeforeDelete extends BaseTrigger {
    
//     public function __construct(){
//         parent::__construct();
//     }
    
//     public function index($id,$data){

//     }
// }