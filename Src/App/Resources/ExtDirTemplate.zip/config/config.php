<?php
\App\Core\Application::$app->globalVar->set('IGNORE_ODK_USERNAMES', array());