</div> <!-- container -->
</div> <!-- content -->

<!-- Footer Start -->
<footer class="footer">
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-6">
            <?php echo \MiscHelper::getGlobalVar('SETTING_APP_COPYRIGHT'); ?>
            </div>
            <div class="col-md-6">
                <div class="text-md-right footer-links d-none d-md-block">
                    <!-- <a href="javascript: void(0);">About</a>
                    <a href="javascript: void(0);">Support</a>
                    <a href="javascript: void(0);">Contact Us</a> -->
                </div>
            </div>
        </div>
    </div>
</footer>
<!-- end Footer -->

</div>

<!-- ============================================================== -->
<!-- End Page content -->
<!-- ============================================================== -->


</div>


<!-- App js -->
<script src="/assets/js/app.min.js"></script>
<script src="/assets/js/vue.min.js"></script>
<script src="/assets/js/axios.min.js"></script>

<!-- <script src="/assets/js/jquery.min.js"></script> -->
<!-- <script src="/assets/js/jquery-ui.js"></script> -->
<script src="/assets/jquery-ui-1.12.1/jquery-ui.min.js"></script>
<script src="/assets/js/jquery_date_picker_dropdown.js"></script>

<script src="/assets/js/vendor/Sortable.min.js"></script>
<script src="/assets/js/vendor/vuedraggable.umd.min.js"></script>

<!-- <script src="/assets/js/popper.min.js"></script> -->
<!-- <script src="/assets/js/bootstrap.min.js"></script> -->



</body>
</html>
