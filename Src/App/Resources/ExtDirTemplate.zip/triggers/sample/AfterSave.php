<?php 

//namespace Ext\Triggers\ctype_name;

// use App\Core\BaseTrigger;

// class AfterSave extends BaseTrigger {
    
//     public function __construct(){
//         parent::__construct();
//     }
    
//     public function index($id, $data, $is_update = false){

//     }
// }