<?php 

namespace Ext\Externalapi;

use App\Core\Controller;
use App\Core\Application;
use App\Exceptions\NotFoundException;

class Sample extends Controller {
    
    private $userObj = null;

    public function __construct(){
        parent::__construct();

        $this->userObj = Application::$app->user->LoginUsingBasicAuth();
    }

    public function index($id, $params){
        throw new NotFoundException();
    }
}
