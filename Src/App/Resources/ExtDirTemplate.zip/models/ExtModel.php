<?php namespace Ext\Models;

  class ExtModel {
        private $db;
        private $core_model;
        public function __construct(){
            $this->db = new \App\Libraries\Database;
            $this->core_model = new \App\Models\CoreModel;
        }
    


}
    