<?php 

// namespace Ext\Triggers\ctype_name;

// use App\Core\BaseTrigger;

// class BeforeUpdateStatus extends BaseTrigger {
    
//     public function __construct(){
//         parent::__construct();
//     }

//     public function index($id,$from_status_id, &$to_status_id, $step = 0, $total_steps = 0, $path = null, &$justification = null){

//     }
// }
