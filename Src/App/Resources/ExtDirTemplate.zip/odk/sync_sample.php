<?php 

// namespace Ext\Odk;

// use App\Core\Gcrons\BaseSyncOdkPreloads;

// class Sample extends BaseSyncOdkPreloads {

//     public function __construct(){
//         parent::__construct();
//     }

//     public function index($id,$params)
//     {

//         $csv_file_name = "name"; //Without .csv
//         $csv_url = "link_to_csv";
        
//         $this->Sync($id, $csv_file_name, $csv_url);

//     }

// }