<?php 
namespace Ext\Actions;

use App\Core\Controller;

class Sample extends Controller {
    
    public function __construct(){
        parent::__construct();

        //Check if user is logged in or on local
        $this->app->user->checkAuthentication();
        
    }

    /**
     * index
     *
     * @param  string $id
     * @param  array $params
     * @return void
     */
    public function index(){
        
    }
}
