<?php 

// namespace Ext\Triggers\ctype_name;

// use App\Core\BaseTrigger;

// class BeforeSave extend BaseTrigger {
    
//     public function __construct(){
//         parent::__construct();
//     }

//     public function index($data, $is_update = false){

//     }
// }
