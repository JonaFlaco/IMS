<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8" />
        <title><?php echo (isset($data['title']) ? $data['title'] : "") . " | " . \MiscHelper::getGlobalVar('SETTING_APP_TITLE') ?></title>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta content="Information Management System - IOM Iraq" name="description" />
        <meta content="IMS" name="author" />
        <!-- App favicon -->
        <link rel="shortcut icon" href="/assets/images/favicon.ico">

        <!-- inline style to handle loading of various element-->
        <style>body.loading {visibility: hidden;}</style>

        <link href="/assets/css/icons.min.css" rel="stylesheet" type="text/css" />
        <link href="/assets/css/app.min.css" rel="stylesheet" type="text/css" id="main-style-container" />
        <link href="/assets/css/style.css" rel="stylesheet" type="text/css" />

        <link href="/assets/css/vue-multiselect.min.css" rel="stylesheet" type="text/css" />
        
        <script src="/assets/js/vue-multiselect.min.js"></script>
        <link href="/assets/jquery-ui-1.12.1/jquery-ui.min.css" rel="stylesheet" type="text/css" />

    </head>

    <?php

    $rtl_prop = "";
    if(get_current_lang_direction() == "rtl"){
        $rtl_prop .= " dir=\"RTL\" ";
        $rtl_prop .= " style=\"text-align: right\" ";
    }

    ?>

    <body <?php echo $rtl_prop ?> class="text-dark">
        <div class="wrapper">

            <!-- Pre-loader -->
            <!-- <div id="preloader">
                <div id="status">
                    <div class="bouncing-loader"><div ></div><div ></div><div ></div></div>
                </div>
            </div> -->
            <!-- End Preloader-->
            <!-- ============================================================== -->
            <!-- Start Page Content here -->
            <!-- ============================================================== -->

            <div class="content-page m-0">
                <div class="content">

                    <!-- Start Content-->
                    <div class="container-fluid">
              
                    <?php if(\MiscHelper::getGlobalVar('SETTING_MAINTENANCE_MODE_IS_ACTIVE') == 1){ ?>
                    <div class="alert alert-danger mt-2" role="alert">
                        <strong>MAINTENANCE MODE IS ACTIVE - </strong> End of maintenance is <?php echo \MiscHelper::getGlobalVar('SETTING_MAINTENANCE_MODE_END_DATE'); ?>
                    </div>
                    <?php } ?>


